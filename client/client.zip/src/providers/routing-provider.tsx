import { AppLayout } from '@/components';
import {
  CreatePatient,
  EditPatient,
  InfinitePatients,
  PaginatedPatients,
  Patients,
} from '@/views';
import {
  Route,
  RouterProvider,
  createBrowserRouter,
  createRoutesFromElements,
} from 'react-router-dom';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route element={<AppLayout />}>
      <Route path="/" element={<Patients />} />
      <Route path="infinite" element={<InfinitePatients />} />
      <Route path="paginated" element={<PaginatedPatients />} />
      <Route path="/patient/create" element={<CreatePatient />} />
      <Route path="/patient/edit/:id" element={<EditPatient />} />
    </Route>
  )
);

export function RoutingProvider() {
  return <RouterProvider router={router} />;
}
