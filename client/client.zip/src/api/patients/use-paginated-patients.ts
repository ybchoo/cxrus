import { apiClient, patientQueryKeys } from '@/api';
import { useQuery } from '@tanstack/react-query';

type Props = {
  page: number;
  pageLimit: number;
};

export function usePaginatedPatients({ page, pageLimit }: Props) {
  const getPaginatedPatientsFn = async (p = page) => {
    const response = await apiClient.get(`?_page=${p}&_limit=${pageLimit}`);
    return response.data;
  };

  return useQuery(
    patientQueryKeys.pagination(page),
    () => getPaginatedPatientsFn(page),
    {
      keepPreviousData: true,
    }
  );
}
