import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient, patientQueryKeys } from '@/api';
import { useToast } from '@/components/ui';
import { TSFixMe, Patient } from '@/types';

const createPatientFn = async (newPatient: Patient) => {
  const response = await apiClient.post('', newPatient);
  return response.data;
};

export function useCreatePatient() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: createPatientFn,
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: patientQueryKeys.all });
    },
    onSuccess: (data) => {
      toast({
        title: 'New Patient Created',
        description: `Id: ${data.id} Name: ${data.name}`,
      });
    },
    onError: (err, newPatient, context?: TSFixMe) => {
      console.log(err, " ", newPatient);
      queryClient.setQueryData(patientQueryKeys.all, context.previousPatients);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: patientQueryKeys.all });
    },
  });
}
