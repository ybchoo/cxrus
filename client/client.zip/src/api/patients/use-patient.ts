import { useParams } from 'react-router-dom';
import { apiClient, patientQueryKeys } from '@/api';
import { useQuery } from '@tanstack/react-query';

export function usePatient() {
  const { id } = useParams();

  const getPatientFn = async () => {
    console.log(id);
    console.log("==========");
    const response = await apiClient.get(`${id}`);
    console.log("###############");
    console.dir(response);
    return response.data;
  };

  return useQuery({
    queryKey: patientQueryKeys.detail(Number(id)),
    queryFn: getPatientFn,
    retry: 1,
  });
}
