import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient, patientQueryKeys } from '@/api';
import { toast } from '@/components/ui';

export interface Props2 {
  closeModal: () => void;
  id?: number;
}

export function useDeletePatient({ closeModal }: Props2) {
  const queryClient = useQueryClient();

  const deletePatientFn = async (id: number) => {
    const response = await apiClient.delete(`${id}`);
    return response;
  };

  return useMutation({
    mutationFn: deletePatientFn,
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: patientQueryKeys.all });
    },
    onSuccess: () => {
      toast({
        title: 'Delete patient successfully',
      });
    },
    onError: () => {
      queryClient.invalidateQueries({ queryKey: patientQueryKeys.all });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: patientQueryKeys.all });
      closeModal();
    },
  });
}
