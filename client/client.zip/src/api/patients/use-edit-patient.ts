import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { apiClient, patientQueryKeys } from '@/api';
import { TSFixMe, Patient } from '@/types';

export function useEditPatient() {
  const { id } = useParams();
  const queryClient = useQueryClient();

 
  const editPatientFn = async (updatedPatient: Patient) => {
    const response = await apiClient.put(`/${id}`, updatedPatient);
    return response;
  };

  return useMutation({
    mutationFn: editPatientFn,
    onMutate: async (updatedPatient) => {
      await queryClient.cancelQueries(patientQueryKeys.detail(Number(id)));
      const previousPatient = queryClient.getQueryData(
        patientQueryKeys.detail(Number(id))
      );
      queryClient.setQueryData(patientQueryKeys.detail(Number(id)), updatedPatient);
      return { previousPatient: previousPatient, updatedPatient: updatedPatient };
    },
    onError: (err, updatedPatient, context?: TSFixMe) => {
      console.log(err, " ", updatedPatient);
      queryClient.setQueryData(
        patientQueryKeys.detail(Number(id)),
        context.previousPatient
      );
    },
    onSettled: () => {
      queryClient.invalidateQueries(patientQueryKeys.all);
    },
  });
}
