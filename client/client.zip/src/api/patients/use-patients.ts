import { apiClient, patientQueryKeys } from '@/api';
import { useQuery } from '@tanstack/react-query';

const getPatientsFn = async () => {
  const response = await apiClient.get('');
  return response.data;
};

export function usePatients() {
  return useQuery({
    queryKey: patientQueryKeys.all,
    queryFn: getPatientsFn,
  });
}
