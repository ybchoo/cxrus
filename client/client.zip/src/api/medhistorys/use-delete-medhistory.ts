import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient, medhistoryQueryKeys } from '@/api';
import { toast } from '@/components/ui';

export interface Props {
  closeModal: () => void;
  id?: number;
}

export function useDeleteMedhistory({ closeModal }: Props) {
  const queryClient = useQueryClient();

  const deleteMedhistoryFn = async (id: number) => {
    const response = await apiClient.delete(`${id}`);
    return response;
  };

  return useMutation({
    mutationFn: deleteMedhistoryFn,
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: medhistoryQueryKeys.all });
    },
    onSuccess: () => {
      toast({
        title: 'Delete medhistory successfully',
      });
    },
    onError: () => {
      queryClient.invalidateQueries({ queryKey: medhistoryQueryKeys.all });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: medhistoryQueryKeys.all });
      closeModal();
    },
  });
}
