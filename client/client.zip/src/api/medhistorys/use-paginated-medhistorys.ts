import { apiClient, medhistoryQueryKeys } from '@/api';
import { useQuery } from '@tanstack/react-query';

type Props = {
  page: number;
  pageLimit: number;
};

export function usePaginatedMedhistorys({ page, pageLimit }: Props) {
  const getPaginatedMedhistorysFn = async (p = page) => {
    const response = await apiClient.get(`?_page=${p}&_limit=${pageLimit}`);
    return response.data;
  };

  return useQuery(
    medhistoryQueryKeys.pagination(page),
    () => getPaginatedMedhistorysFn(page),
    {
      keepPreviousData: true,
    }
  );
}
