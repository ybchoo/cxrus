import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { apiClient, medhistoryQueryKeys } from '@/api';
import { TSFixMe, Medhistory } from '@/types';

export function useEditMedhistory() {
  const { id } = useParams();
  const queryClient = useQueryClient();

  // https://react-query.tanstack.com/guides/optimistic-updates#updating-a-single-todo
  const editMedhistoryFn = async (updatedMedhistory: Medhistory) => {
    const response = await apiClient.put(`/${id}`, updatedMedhistory);
    return response;
  };

  return useMutation({
    mutationFn: editMedhistoryFn,
    onMutate: async (updatedMedhistory) => {
      await queryClient.cancelQueries(medhistoryQueryKeys.detail(Number(id)));
      const previousMedhistory = queryClient.getQueryData(
        medhistoryQueryKeys.detail(Number(id))
      );
      queryClient.setQueryData(medhistoryQueryKeys.detail(Number(id)), updatedMedhistory);
      return { previousMedhistory: previousMedhistory, updatedMedhistory: updatedMedhistory };
    },
    onError: (err, updatedMedhistory, context?: TSFixMe) => {
      console.log(err+" "+updatedMedhistory);    
      queryClient.setQueryData(
        medhistoryQueryKeys.detail(Number(id)),
        context.previousMedhistory
      );
    },
    onSettled: () => {
      queryClient.invalidateQueries(medhistoryQueryKeys.all);
    },
  });
}
