import { useParams } from 'react-router-dom';
import { apiClient, medhistoryQueryKeys } from '@/api';
import { useQuery } from '@tanstack/react-query';

export function useMedhistory() {
  const { id } = useParams();

  const getMedhistoryFn = async () => {
    const response = await apiClient.get(`${id}`);
    return response.data;
  };

  return useQuery({
    queryKey: medhistoryQueryKeys.detail(Number(id)),
    queryFn: getMedhistoryFn,
    retry: 1,
  });
}
