import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient, medhistoryQueryKeys } from '@/api';
import { useToast } from '@/components/ui';
import { TSFixMe, Medhistory } from '@/types';

const createMedhistoryFn = async (newMedhistory: Medhistory) => {
  const response = await apiClient.post('', newMedhistory);
  return response.data;
};

// https://tanstack.com/query/latest/docs/react/guides/optimistic-updates
export function useCreateMedhistory() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: createMedhistoryFn,
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: medhistoryQueryKeys.all });
    },
    onSuccess: (data) => {
      toast({
        title: 'New Medhistory Created',
        description: `Id: ${data.id} Name: ${data.description} ${data.visitdate} ${data.pid}`,
      });
    },
    onError: (err, newMedhistory, context?: TSFixMe) => {
      console.log(err+" "+newMedhistory);
      queryClient.setQueryData(medhistoryQueryKeys.all, context.previousMedhistorys);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: medhistoryQueryKeys.all });
    },
  });
}
