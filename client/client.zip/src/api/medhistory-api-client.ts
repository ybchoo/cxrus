import axios from 'axios';

export const apiMedhistory = axios.create({
  baseURL: 'http://localhost:3004/medhistory/',
});
