
export type Medhistory = Partial<{
  id: number;
  description: string;
  visitdate: string;
  pid: string;
}>;

export type Patient = Partial<{
  id: number;
  name: string;
  age: string;
  address: string;
  createdon: string;
  defuncton: string;
  medhistory: Array<Medhistory>;
}>;


// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type TSFixMe = any;
