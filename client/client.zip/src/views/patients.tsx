import { PatientTable } from '@/components';
import { usePatients } from '@/api';

export function Patients() {
  const patients = usePatients();

  return (
    <div>
      <h2 className="mb-4">Basic Query Example</h2>
      <div>
        {patients.isLoading && (
          <div className="py-2 text-teal-900 font-bold">Loading...</div>
        )}

        {patients.isFetching && (
          <div className="py-2 text-teal-900 font-bold">Fetching...</div>
        )}

        {patients.error instanceof Error && <div>{patients.error.message}</div>}

        {patients.isSuccess && (
          <div>
            <PatientTable patients={patients.data} />
          </div>
        )}
      </div>
    </div>
  );
}
