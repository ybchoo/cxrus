export * from './create-patient';
export * from './edit-patient';
export * from './infinite-patients';
export * from './paginated-patients';
export * from './patients';

export * from './create-medhistory';
export * from './edit-medhistory';
export * from './infinite-medhistorys';
export * from './paginated-medhistorys';
export * from './medhistorys';