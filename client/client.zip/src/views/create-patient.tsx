import { Navigate } from 'react-router-dom';
import { PatientForm } from '@/components';
import { useCreatePatient } from '@/api';
import { Patient } from '@/types';

export function CreatePatient() {
  const createPatient = useCreatePatient();

  const onSubmit = async (data: Patient) => createPatient.mutate(data);

  // https://reactrouter.com/docs/en/v6/upgrading/v5#use-usenavigate-instead-of-usehistory
  if (createPatient.isSuccess) {
    return <Navigate to="/" replace />;
  }

  return (
    <div>
      <h2>New Patient</h2>

      {createPatient.isLoading && <div>Loading...</div>}

      {createPatient.error instanceof Error && (
        <div>An error occurred: {createPatient.error.message}</div>
      )}

      <PatientForm submitText="Create" submitAction={onSubmit} />
    </div>
  );
}
