import { MedhistoryTable } from '@/components';
import { useMedhistorys } from '@/api';

export function Medhistorys() {
  const medhistorys = useMedhistorys();

  return (
    <div>
      <h2 className="mb-4">Basic Query Example</h2>
      <div>
        {medhistorys.isLoading && (
          <div className="py-2 text-teal-900 font-bold">Loading...</div>
        )}

        {medhistorys.isFetching && (
          <div className="py-2 text-teal-900 font-bold">Fetching...</div>
        )}

        {medhistorys.error instanceof Error && <div>{medhistorys.error.message}</div>}

        {medhistorys.isSuccess && (
          <div>
            <MedhistoryTable medhistorys={medhistorys.data} />
          </div>
        )}
      </div>
    </div>
  );
}
