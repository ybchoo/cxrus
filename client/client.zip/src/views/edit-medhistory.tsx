import { Navigate } from 'react-router-dom';
import { MedhistoryForm } from '@/components';
import { useEditMedhistory, useMedhistory } from '@/api';
import { Medhistory } from '@/types';

export function EditMedhistory() {
  const getMedhistory = useMedhistory();
  const editMedhistory = useEditMedhistory();

  const onSubmit = async (data: Medhistory) => editMedhistory.mutate(data);

  // https://reactrouter.com/docs/en/v6/upgrading/v5#use-usenavigate-instead-of-usehistory
  if (editMedhistory.isSuccess) {
    return <Navigate to="/" replace />;
  }

  return (
    <div>
      <h2>Edit Medhistory</h2>
      <div>
        {getMedhistory.isLoading && <div>Loading...</div>}

        {getMedhistory.error instanceof Error && <div>{getMedhistory.error.message}</div>}

        {getMedhistory.data && (
          <MedhistoryForm
            medhistory={getMedhistory.data}
            submitText="Update"
            submitAction={onSubmit}
          />
        )}
      </div>
    </div>
  );
}
