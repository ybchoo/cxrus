import { Navigate } from 'react-router-dom';
import { PatientForm } from '@/components';
import { useEditPatient, usePatient } from '@/api';
import { Patient } from '@/types';

export function EditPatient() {
  const getPatient = usePatient();
  const editPatient = useEditPatient();

  const onSubmit = async (data: Patient) => editPatient.mutate(data);


  if (editPatient.isSuccess) {
    return <Navigate to="/" replace />;
  }

  return (
    <div>
      <h2>Edit Patient</h2>
      <div>
        {getPatient.isLoading && <div>Loading...</div>}

        {getPatient.error instanceof Error && <div>{getPatient.error.message}</div>}

        {getPatient.data && (
          <PatientForm
            patient={getPatient.data}
            submitText="Update"
            submitAction={onSubmit}
          />
        )}
      </div>

    </div>
  );
}
