import { Navigate } from 'react-router-dom';
import { MedhistoryForm } from '@/components';
import { useCreateMedhistory } from '@/api';
import { Medhistory } from '@/types';

export function CreateMedhistory() {
  const createMedhistory = useCreateMedhistory();

  const onSubmit = async (data: Medhistory) => createMedhistory.mutate(data);

  // https://reactrouter.com/docs/en/v6/upgrading/v5#use-usenavigate-instead-of-usehistory
  if (createMedhistory.isSuccess) {
    return <Navigate to="/" replace />;
  }

  return (
    <div>
      <h2>New Medhistory</h2>

      {createMedhistory.isLoading && <div>Loading...</div>}

      {createMedhistory.error instanceof Error && (
        <div>An error occurred: {createMedhistory.error.message}</div>
      )}

      <MedhistoryForm submitText="Create" submitAction={onSubmit} />
    </div>
  );
}
