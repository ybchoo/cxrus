import { Fragment } from 'react';
import { useInfiniteMedhistorys } from '@/api';
import { Medhistory } from '@/types';

export function InfiniteMedhistorys() {
  const pageLimit = 10;
  const infiniteMedhistorys = useInfiniteMedhistorys({ pageLimit });
  let medhistoryList;

  if (infiniteMedhistorys.data) {
    medhistoryList = infiniteMedhistorys.data.pages.map((page, index) => (
      <Fragment key={index}>
        {page.data.map((medhistory: Medhistory) => (
          <li key={medhistory.id}>
            {medhistory.id}. {medhistory.description} {medhistory.visitdate}
          </li>
        ))}
      </Fragment>
    ));
  }

  return (
    <div>
      <h2>Infinite Medhistorys</h2>
      <div>
        {infiniteMedhistorys.error instanceof Error && (
          <div>An error occurred: {infiniteMedhistorys.error.message}</div>
        )}

        {infiniteMedhistorys.isFetchingNextPage && <div>Fetching Next Page...</div>}

        {infiniteMedhistorys.isSuccess && <ul className="my-4 ml-4">{medhistoryList}</ul>}
      </div>
      <div>
        <button
          className="btn btn-load"
          onClick={() => infiniteMedhistorys.fetchNextPage()}
          disabled={
            !infiniteMedhistorys.hasNextPage || infiniteMedhistorys.isFetchingNextPage
          }
        >
          Load More...
        </button>
      </div>
    </div>
  );
}
