import { Fragment } from 'react';
import { useInfinitePatients } from '@/api';
import { Patient } from '@/types';

export function InfinitePatients() {
  const pageLimit = 10;
  const infinitePatients = useInfinitePatients({ pageLimit });
  let patientList;

  if (infinitePatients.data) {
    patientList = infinitePatients.data.pages.map((page, index) => (
      <Fragment key={index}>
        {page.data.map((patient: Patient) => (
          <li key={patient.id}>
            {patient.id}. {patient.name}
          </li>
        ))}
      </Fragment>
    ));
  }

  return (
    <div>
      <h2>Infinite Patients</h2>
      <div>
        {infinitePatients.error instanceof Error && (
          <div>An error occurred: {infinitePatients.error.message}</div>
        )}

        {infinitePatients.isFetchingNextPage && <div>Fetching Next Page...</div>}

        {infinitePatients.isSuccess && <ul className="my-4 ml-4">{patientList}</ul>}
      </div>
      <div>
        <button
          className="btn btn-load"
          onClick={() => infinitePatients.fetchNextPage()}
          disabled={
            !infinitePatients.hasNextPage || infinitePatients.isFetchingNextPage
          }
        >
          Load More...
        </button>
      </div>
    </div>
  );
}
