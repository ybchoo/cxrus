import { useDeleteMedhistory } from '@/api';
import { DeleteModal } from '@/components';
import { AiOutlineDelete, AiOutlineEdit } from '@/icons';
import { Medhistory } from '@/types';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import './medhistory-table.css';

type Props = {
  medhistorys: Medhistory[];
};

export function MedhistoryTable({ medhistorys }: Props) {
  const [deleteId, setDeleteId] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);

  function closeModal() {
    setIsModalOpen(false);
  }

  function showDeleteModal(id: number) {
    setDeleteId(id);
    setIsModalOpen(true);
  }

  const deleteMutation = useDeleteMedhistory({ closeModal });

  const handleDelete = async (id: number) => {
    deleteMutation.mutateAsync(id);
  };

  return (
    <>
      <DeleteModal
        id={deleteId}
        isModalOpen={isModalOpen}
        cancelAction={closeModal}
        deleteAction={handleDelete}
        isLoading={deleteMutation.isLoading}
      />

      <div className="flex justify-between items-center mb-4">
        <Link
          to="/medhistory/create"
          className="py-1 px-4 font-semibold text-teal-900 rounded border-2 border-teal-700 hover:text-white hover:bg-teal-800 hover:border-none"
        >
          Create Medhistory
        </Link>
      </div>
      <table className="table-fixed text-gray-800">
        <thead className="text-white bg-cyan-900">
          <tr className="py-4">
            <th className="w-1/12">Id</th>
            <th className="w-3/12">Description</th>
            <th className="w-3/12">Visit Date</th>
            <th className="w-3/12">Patient ID</th>
          </tr>
        </thead>
        <tbody>
          {medhistorys &&
            medhistorys.map((medhistory: Medhistory) => (
              <tr
                className="bg-white border border-cyan-800 hover:bg-lime-100 active:text-lime-100 active:bg-lime-700"
                key={medhistory.id}
              >
                <td>{medhistory.id}</td>
                <td>{medhistory.description}</td>
                <td>{medhistory.visitdate}</td>

                <td className="inline-flex border-none">
                  <Link
                    className="p-2 text-cyan-800 hover:text-cyan-500"
                    to={`/medhistory/edit/${medhistory.id}`}
                  >
                    <AiOutlineEdit />
                  </Link>
                  <button
                    className="p-2 text-cyan-800 hover:text-cyan-500"
                    onClick={() => showDeleteModal(medhistory.id!)}
                  >
                    <AiOutlineDelete />
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </>
  );
}
