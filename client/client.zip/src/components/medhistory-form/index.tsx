import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import './medhistory-form.css';

export function MedhistoryForm({ medhistory, submitText, submitAction }: any) {
  const {
    register,
    formState: { errors },
    handleSubmit,
  } = useForm({
    defaultValues: medhistory || {},
    // https://react-hook-form.com/api/useform, see defaultValues: Record<string, any> = {}
  });

  const navigate = useNavigate();
  const back = () => navigate('/');

  return (
    <div>
      <form className="mt-4 max-w-md" onSubmit={handleSubmit(submitAction)}>
        {medhistory && (
          <div className="field">
            <label htmlFor="id">Medhistory Id</label>
            <input type="text" name="id" value={medhistory.id} disabled />
          </div>
        )}

        <div className="flex flex-col md:flex-row field">
          <div>
            <label htmlFor="description">Description</label>
            <input
              type="text"
              {...register('description', { required: true })}
            />
            <span className="errors">
              {errors.first_name && 'Description is required'}
            </span>
          </div>
          <div className="mt-2 md:mt-0 md:ml-4">
            <label htmlFor="visitdate">Visit Date</label>
            <input type="text" {...register('visitdate', { required: true })} />
            <span className="errors">
              {errors.visitdate && 'Visit Date is required'}
            </span>
          </div>
        </div>


        <div className="flex justify-between mt-8">
          <button
            className="text-white bg-teal-800 border-teal-800 shadow-md hover:text-teal-900 hover:bg-gray-100 hover:border-2 btn"
            type="submit"
          >
            {submitText}
          </button>
          <button
            className="text-gray-600 border-2 border-gray-600 shadow-md hover:text-gray-100 hover:bg-gray-600 btn"
            type="button"
            onClick={back}
          >
            Back
          </button>
        </div>
      </form>
    </div>
  );
}
