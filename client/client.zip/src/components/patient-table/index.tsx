import { useDeletePatient } from '@/api';
import { DeleteModal } from '@/components';
import { AiOutlineDelete, AiOutlineEdit } from '@/icons';
import { Patient } from '@/types';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import './patient-table.css';

type Props = {
  patients: Patient[];
};

export function PatientTable({ patients }: Props) {
  const [deleteId, setDeleteId] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);

  function closeModal() {
    setIsModalOpen(false);
  }

  function showDeleteModal(id: number) {
    setDeleteId(id);
    setIsModalOpen(true);
  }

  const deleteMutation = useDeletePatient({ closeModal });

  const handleDelete = async (id: number) => {
    deleteMutation.mutateAsync(id);
  };

  return (
    <>
      <DeleteModal
        id={deleteId}
        isModalOpen={isModalOpen}
        cancelAction={closeModal}
        deleteAction={handleDelete}
        isLoading={deleteMutation.isLoading}
      />

      <div className="flex justify-between items-center mb-4">
        <Link
          to="/patient/create"
          className="py-1 px-4 font-semibold text-teal-900 rounded border-2 border-teal-700 hover:text-white hover:bg-teal-800 hover:border-none"
        >
          Create Patient
        </Link>
      </div>
      <table className="table-fixed text-gray-800">
        <thead className="text-white bg-cyan-900">
          <tr className="py-4">
            
            <th className="w-3/12">Name</th>
            <th className="w-3/12">Age</th>
            <th className="w-3/12">Address</th>
            <th className="w-3/12">Action</th>
          </tr>
        </thead>
        <tbody>
          {patients &&
            patients.map((patient: Patient) => (
              <tr
                className="bg-white border border-cyan-800 hover:bg-lime-100 active:text-lime-100 active:bg-lime-700"
                key={patient.id}
              >
                <td>{patient.name}</td>
                <td>{patient.age}</td>
                <td>{patient.address}</td>
                
                <td className="inline-flex border-none">
                  <Link
                    className="p-2 text-cyan-800 hover:text-cyan-500"
                    to={`/patient/edit/${patient.id}`}
                  >
                    <AiOutlineEdit />
                  </Link>
                  
                  <button
                    className="p-2 text-cyan-800 hover:text-cyan-500"
                    onClick={() => showDeleteModal(patient.id!)}
                  >
                    <AiOutlineDelete />
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </>
  );
}

