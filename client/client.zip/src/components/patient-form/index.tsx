import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import './patient-form.css';
import { MedhistoryTable } from '@/components';
import { useMedhistorys } from '@/api';
export function PatientForm({ patient, submitText, submitAction }: any) {
  const {
    register,
    formState: { errors },
    handleSubmit,
  } = useForm({
    defaultValues: patient || {},

  });
  

  const medhistorys = useMedhistorys();
  
  const navigate = useNavigate();
  const back = () => navigate('/');

  return (
    <div>
      <form className="mt-4 max-w-md" onSubmit={handleSubmit(submitAction)}>
        {patient && (
          <div className="field">
            <label htmlFor="id">Patient Id</label>
            <input type="text" name="id" value={patient.id} disabled />
          </div>
        )}

        <div className="flex flex-col md:flex-row field">
          <div>
            <label htmlFor="name">Name</label>
            <input
              type="text"
              {...register('name', { required: true })}
            />
            <span className="errors">
              {errors.name && 'Name is required'}
            </span>
          </div>

          <div className="mt-2 md:mt-0 md:ml-4">
            <label htmlFor="age">Age</label>
            <input type="number" {...register('age', { required: true })} />
            <span className="errors">
              {errors.age && 'Age is required'}
            </span>
          </div>
        </div>

        <div className="field">
          <label htmlFor="address">Address</label>
          <input
            type="address"
            {...register('address', { required: true })}
          />
          <span className="errors">
            {errors.address &&
              errors.address.type === 'required' &&
              'Address is required'}
          </span>
        </div>

        <div className="flex justify-between mt-8">
          <button
            className="text-white bg-teal-800 border-teal-800 shadow-md hover:text-teal-900 hover:bg-gray-100 hover:border-2 btn"
            type="submit"
          >
            {submitText}
          </button>
          <button
            className="text-gray-600 border-2 border-gray-600 shadow-md hover:text-gray-100 hover:bg-gray-600 btn"
            type="button"
            onClick={back}
          >
            Back
          </button>
        </div>
        
      </form>

      <div><h3>Medical History</h3></div>
      <div>
        {medhistorys.isLoading && (
          <div className="py-2 text-teal-900 font-bold">Loading...</div>
        )}

        {medhistorys.isFetching && (
          <div className="py-2 text-teal-900 font-bold">Fetching...</div>
        )}

        {medhistorys.error instanceof Error && <div>{medhistorys.error.message}</div>}

        {medhistorys.isSuccess && (
          <div>
            <MedhistoryTable medhistorys={medhistorys.data} />
          </div>
        )}
      </div>
    </div>
    
  );
}

