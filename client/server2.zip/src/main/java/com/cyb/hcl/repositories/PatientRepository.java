package com.cyb.hcl.repositories;

import com.cyb.hcl.entity.PatientEntity;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@Qualifier("patients")
public interface PatientRepository extends JpaRepository<PatientEntity, Integer>{

  @Query(value = "SELECT * FROM  hcl.patients LIMIT 0, 10;", nativeQuery = true)
  Optional<List<PatientEntity>> getTopPatients();

}
