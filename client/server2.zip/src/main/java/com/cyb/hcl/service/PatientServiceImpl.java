package com.cyb.hcl.service;
import com.cyb.hcl.entity.PatientEntity;
import com.cyb.hcl.repositories.MedicalHistoryRepository;
import com.cyb.hcl.repositories.PatientRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientServiceImpl implements PatientService{

  protected static final Logger logger =
      LoggerFactory.getLogger(PatientServiceImpl.class);
  @Autowired
  private final PatientRepository patientRepository;

  @Autowired
  private final MedicalHistoryRepository medicalHistoryRepository;

  @Autowired
  public PatientServiceImpl(
      PatientRepository patientRepository,
      MedicalHistoryRepository medicalHistoryRepository) {
    this.patientRepository = patientRepository;
    this.medicalHistoryRepository = medicalHistoryRepository;
  }

  public Optional<PatientEntity> getPatientById(int id) {
    return patientRepository.findById(id);
  }

  public List<PatientEntity> getPatients()
  {
    return patientRepository.findAll();
  }

  public Optional<List<PatientEntity>> getTopTenPatients()
  {
    return patientRepository.getTopPatients();
  }

  public PatientEntity savePatient(PatientEntity patientEntity) {

    PatientEntity _patientEntity = patientRepository.save(patientEntity);
    return _patientEntity;
  }

  public String updatePatient(PatientEntity patientEntity) {
    if (patientEntity != null) {
      long _id = patientEntity.getId();
      if (!patientRepository.findById((int)_id).isEmpty()) {
        logger.info("############## Error Here 1");
        patientRepository.save(patientEntity);
        logger.info("############## Error Here 2");
        return "Patient ["+_id +"} Updated Successfully";
      } else {
        return "Patient ["+_id +"} Not Found";
      }
    }
    return "Cannot Update Null Object";
  }

  public String deletePatient(int id) {
    if (!patientRepository.findById(id).isEmpty()) {
      patientRepository.deleteById(id);
      return "Deleted Successfully";
    } else {
      return "Patient Id Not Found";
    }
  }
}
