package com.cyb.hcl.service;

import com.cyb.hcl.entity.MedicalHistoryEntity;
import com.cyb.hcl.repositories.MedicalHistoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public interface MedicalHistoryService {

  public Optional<List<MedicalHistoryEntity>> findMedicalHistoryByPatientId(long id);
  public Optional<MedicalHistoryEntity> findByMedicalHistoryId(long num);
  public List<MedicalHistoryEntity> getMedicalHistories();
  public Optional<List<MedicalHistoryEntity>> getTopTenMedicalHistorys() ;
  public MedicalHistoryEntity saveMedicalHistory(MedicalHistoryEntity medicalHistoryEntity);
  public String updateMedicalHistory(MedicalHistoryEntity medicalHistoryEntity);
  public String deleteMedicalHistory(int id);
}
