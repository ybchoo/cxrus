package com.cyb.hcl.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity(name = "patients")
@NoArgsConstructor
@Table(name = "patients")
@JsonIdentityInfo(
    generator= ObjectIdGenerators.PropertyGenerator.class,
    property="id",
    scope= PatientEntity.class)
public class PatientEntity {
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Id
  @JsonProperty("id")
  @Column(name="id")
  private Long id;

  @Column(name = "name", nullable = false, length = 40)
  private String name;

  @Column(name = "age", nullable = false)
  private int age;

  @Column(name = "address")
  private String address;

  @Column(name = "createdOn", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", length = 0)
  private LocalDateTime createdon;

  @Column(name = "defunctOn", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", length = 0)
  private LocalDateTime defuncton;

  @OneToMany(mappedBy = "patientList",
      cascade = { CascadeType.PERSIST,
          CascadeType.MERGE, CascadeType.DETACH,
      CascadeType.REFRESH }, fetch = FetchType.LAZY)
//  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
//  @JoinColumn(name = "patient_id")
  private List<MedicalHistoryEntity> medicalhistoryList = new ArrayList<>();

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public LocalDateTime getCreatedon() {
    return createdon;
  }

  public void setCreatedon(LocalDateTime createdon) {
    this.createdon = createdon;
  }

  public LocalDateTime getDefuncton() {
    return defuncton;
  }

  public void setDefuncton(LocalDateTime defuncton) {
    this.defuncton = defuncton;
  }

  public List<MedicalHistoryEntity> getMedicalhistoryList() {
    return medicalhistoryList;
  }

  public void setMedicalhistoryList(List<MedicalHistoryEntity> medicalhistoryList) {
    this.medicalhistoryList = medicalhistoryList;
  }

  @Override
  public String toString() {
    return "PatientEntity{" +
        "address='" + address + '\'' +
        ", id=" + id +
        ", name='" + name + '\'' +
        ", age='" + age + '\'' +
        ", createdon=" + createdon +
        ", defuncton=" + defuncton +
        '}';
  }
}
