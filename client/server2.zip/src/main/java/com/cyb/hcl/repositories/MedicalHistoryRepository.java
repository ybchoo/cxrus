package com.cyb.hcl.repositories;

import com.cyb.hcl.entity.MedicalHistoryEntity;
import com.cyb.hcl.entity.PatientEntity;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@Qualifier("medicalhistory")
public interface MedicalHistoryRepository extends
      JpaRepository<MedicalHistoryEntity, Integer> {
  @Query(value = "SELECT * FROM hcl.medicalhistory where pid = %:pid% ", nativeQuery = true)
  MedicalHistoryEntity findMedicalHistoryByPatientId(@Param("pid")  long pid);

  @Query(value = "SELECT * FROM hcl.medicalhistory where id=$:id", nativeQuery = true)
  Optional<MedicalHistoryEntity> findMedicalHistoryById(@Param("id")  long id);

  @Query(value = "SELECT * FROM hcl.medicalhistory where pid=$:pid", nativeQuery = true)
  Optional<PatientEntity> findMedicalHistoryAndPatientById(@Param("id")  long id,
                                                           @Param("pid")  long pid );

}
