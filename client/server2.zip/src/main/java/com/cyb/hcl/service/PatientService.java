package com.cyb.hcl.service;

import com.cyb.hcl.entity.PatientEntity;
import com.cyb.hcl.repositories.PatientRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public interface PatientService {
    public Optional<PatientEntity> getPatientById(int id) ;
    public List<PatientEntity> getPatients();
    public PatientEntity savePatient(PatientEntity patientEntity);
    public String updatePatient(PatientEntity patientEntity);
    public String deletePatient(int id);
}
