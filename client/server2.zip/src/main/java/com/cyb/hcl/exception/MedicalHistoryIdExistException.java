package com.cyb.hcl.exception;

public class MedicalHistoryIdExistException extends RuntimeException{
  private static final long serialVersionUID = -7785997268261032127L;
  public MedicalHistoryIdExistException(String message) {
    super(message);
  }
}
