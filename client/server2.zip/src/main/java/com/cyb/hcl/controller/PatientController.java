package com.cyb.hcl.controller;
import java.util.List;
import java.util.Optional;

import com.cyb.hcl.entity.MedicalHistoryEntity;
import com.cyb.hcl.exception.PatientIdExistException;
import com.cyb.hcl.exception.handler.HandlerException;

import com.cyb.hcl.entity.PatientEntity;
import com.cyb.hcl.service.MedicalHistoryService;
import com.cyb.hcl.service.PatientService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(
    consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class PatientController {
  protected static final Logger logger = LoggerFactory.getLogger(PatientController.class);
  @Autowired
  private final PatientService patientService;
  @Autowired
  private final MedicalHistoryService medicalHistoryService;

  public PatientController(PatientService patientService, MedicalHistoryService medicalHistoryService) {
    this.patientService = patientService;
    this.medicalHistoryService = medicalHistoryService;
  }

  @GetMapping("/patient/{id}")
  @ResponseStatus(code = HttpStatus.OK)
  public ResponseEntity<PatientEntity> getPatientById(
      @PathVariable Integer id) {
    logger.info("============Inside getPatientById  [[["+id+"]]");
    System.out.println("===========Inside getPatientById");
    Optional<PatientEntity> _patient =
        patientService.getPatientById(id);
    if (_patient.isPresent()) {
      logger.info("Data Present");
      logger.info(_patient.toString());
      Optional<List<MedicalHistoryEntity>> _medicalHistory =
          medicalHistoryService.findMedicalHistoryByPatientId(id);
      if (_medicalHistory.isPresent()) {
        _patient.get().setMedicalhistoryList(
              _medicalHistory.get());
      }
      return ResponseEntity.ok(_patient.get());
    } else {
      HandlerException _handlerException = new HandlerException();
      return (ResponseEntity<PatientEntity>) _handlerException.handlePatientNotFoundException(
          new PatientIdExistException("id [["+ id +"]] Not Found "));    }
  }

  @GetMapping("/patients")
  public ResponseEntity getPatients() {
    logger.info("=========================");
    logger.info("Inside getPatients");
    System.out.println("=========================");
    System.out.println("Inside getPatients");
    List<PatientEntity> _patientList =
        patientService.getPatients();
    return ResponseEntity.ok(_patientList);
  }

  @GetMapping("/patients/top-ten")
  public ResponseEntity getTopTenPatients() {
    logger.info("Inside getTopTenPatients");
    System.out.println("Inside getTopTenPatients");
    List<PatientEntity> _patientList =
        patientService.getPatients();
    if (!_patientList.isEmpty()) {
      return ResponseEntity.ok(_patientList);
    } else {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
  }

  @PostMapping("/patient")
  public ResponseEntity  savePatient(@RequestBody PatientEntity patientEntity) {
    PatientEntity _patient =
        patientService.savePatient(patientEntity);
    return ResponseEntity.ok(_patient);
  }

  @PutMapping("/patient")
  public ResponseEntity updatePatient(
      @RequestBody PatientEntity patientEntity) {
    int id = patientEntity.getId().intValue();
    Optional<PatientEntity> _patient =
        patientService.getPatientById(id);
    if (_patient.isPresent()) {
      String _string =
          patientService.updatePatient(patientEntity);
      return ResponseEntity.ok(_string);
    } else {
      HandlerException _handlerException = new HandlerException();
      return (ResponseEntity<PatientEntity>) _handlerException.handlePatientNotFoundException(
          new PatientIdExistException("patient id [["+ id +"]] Not Found "));
    }
  }

  @DeleteMapping("/patient/{id}")
  @ResponseStatus( code = HttpStatus.NO_CONTENT )
  public ResponseEntity deletePatient(@PathVariable int id) {
    String _string = patientService.deletePatient(id);
    return ResponseEntity.ok(_string);
  }
}
