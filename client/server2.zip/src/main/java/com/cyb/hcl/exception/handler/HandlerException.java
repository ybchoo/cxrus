package com.cyb.hcl.exception.handler;

import com.cyb.hcl.exception.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class HandlerException extends ResponseEntityExceptionHandler {

  @ExceptionHandler(value = {MedicalHistoryNotFoundException.class})
  public ResponseEntity<?> handleMedicalHistoryNotFound(
        MedicalHistoryIdExistException _medicalHistoryIdExistException) {
    return handleExceptionInternal(_medicalHistoryIdExistException,
        _medicalHistoryIdExistException.getMessage(),
        new HttpHeaders(), HttpStatus.NOT_ACCEPTABLE, null);
  }

  @ExceptionHandler(value = {PatientNotFoundException.class})
  public ResponseEntity<?> handlePatientNotFoundException(PatientIdExistException _patientIdExistException) {
    return handleExceptionInternal(_patientIdExistException,
        _patientIdExistException.getMessage(),
        new HttpHeaders(), HttpStatus.NOT_ACCEPTABLE, null);
  }

}
