package com.cyb.hcl.exception;

public class PatientNotFoundException extends RuntimeException {
  private static final long serialVersionUID = 3664641185936711613L;
  public PatientNotFoundException(String message) {
    super(message);
  }
}
