package com.cyb.hcl.exception;

public class PatientIdExistException extends RuntimeException {
  private static final long serialVersionUID = 3664641185936711613L;
  public PatientIdExistException(String message) {
    super(message);
  }
}
