package com.cyb.hcl.exception;

public class MedicalHistoryNotFoundException extends RuntimeException {
  private static final long serialVersionUID = 4276827183204991657L;
  public MedicalHistoryNotFoundException(String message) {
    super(message);
  }
}
