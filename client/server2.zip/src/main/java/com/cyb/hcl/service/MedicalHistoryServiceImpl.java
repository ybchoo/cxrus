package com.cyb.hcl.service;

import com.cyb.hcl.entity.MedicalHistoryEntity;
import com.cyb.hcl.repositories.MedicalHistoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicalHistoryServiceImpl implements MedicalHistoryService {
  protected static final Logger logger =
      LoggerFactory.getLogger(MedicalHistoryServiceImpl.class);

  @Autowired
  private final MedicalHistoryRepository medicalHistoryRepository;

  public MedicalHistoryServiceImpl(MedicalHistoryRepository medicalHistoryRepository)
  {
    this.medicalHistoryRepository = medicalHistoryRepository;
  }

  @Override
  public Optional<List<MedicalHistoryEntity>> findMedicalHistoryByPatientId(long id) {
    return Optional.empty();
  }

  public Optional<MedicalHistoryEntity> findByMedicalHistoryId(long num) {
    return medicalHistoryRepository.findMedicalHistoryById(num);
  }

  public List<MedicalHistoryEntity> getMedicalHistories() {
    return medicalHistoryRepository.findAll();
  }

  public Optional<List<MedicalHistoryEntity>> getTopTenMedicalHistorys() {
    return null;
  }

  public MedicalHistoryEntity saveMedicalHistory(MedicalHistoryEntity medicalHistoryEntity) {
    MedicalHistoryEntity _medicalHistoryEntity = medicalHistoryRepository.save(medicalHistoryEntity);
    return _medicalHistoryEntity;
  }

  public String updateMedicalHistory(MedicalHistoryEntity medicalHistoryEntity) {
    if (medicalHistoryEntity != null) {
      long _id = medicalHistoryEntity.getId();
      if (!medicalHistoryRepository.findById((int)_id).isEmpty()) {
        medicalHistoryRepository.save(medicalHistoryEntity);
        return "Medical History ["+_id +"} Updated Successfully";
      } else {
        return "Medical History ["+_id +"} Not Found";
      }
    }
    return "Cannot Update Null Object";
  }

  public String deleteMedicalHistory(int id) {
    if (!medicalHistoryRepository.findById(id).isEmpty()) {
      medicalHistoryRepository.deleteById(id);
      return "Deleted Successfully";
    } else {
      return "Medical History Id Not Found";
    }
  }
}
