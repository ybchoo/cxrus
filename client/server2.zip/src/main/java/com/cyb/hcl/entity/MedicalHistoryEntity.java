package com.cyb.hcl.entity;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity(name = "medicalhistory")
@NoArgsConstructor
@Table(name = "medicalhistory")
@JsonIdentityInfo(
    generator= ObjectIdGenerators.PropertyGenerator.class,
    property="id",
    scope= MedicalHistoryEntity.class)

public class MedicalHistoryEntity {

  private static final long serialVersionUID = -4123491590764134142L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @JsonProperty("id")
  @Column(name = "id")
  private Long id;


  @Column(name = "description", nullable = false)
  @JsonProperty("description")
  private String description;

  @Column(name = "visitdate", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", length = 0, nullable = false)
  @JsonProperty("visitdate")
  private LocalDateTime visitdate;

//  @ManyToOne
//  @JoinColumn(name = "patient_id")
//  @JsonIgnore

  public PatientEntity getPatientList() {
    return patientList;
  }

  public void setPatientList(PatientEntity patientList) {
    this.patientList = patientList;
  }

  @ManyToOne(cascade = { CascadeType.PERSIST,
      CascadeType.MERGE,
      CascadeType.DETACH,
      CascadeType.REFRESH })
  @JoinColumn(name = "pid")
  private PatientEntity patientList;

  public LocalDateTime getVisitdate() {
    return visitdate;
  }

  public void setVisitdate(LocalDateTime visitdate) {
    this.visitdate = visitdate;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id)
  {
    this.id = id;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public String toString() {
    return "MedicalHistoryEntity{" +
        "description='" + description + '\'' +
        ", medicalhistoryId=" + id +
        ", visitdate=" + visitdate +
        '}';
  }

}
